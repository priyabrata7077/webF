from django.contrib.auth import login,authenticate
from django.http import HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from frontend.models import *


# Create your views here.
#def Index(request):
    #return render(request, 'dashboard/index.html')

def logout_view(request):
    logout(request)
    return redirect('dashboard')
def dashboard(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('panel')  # Replace 'panel' with the desired URL after successful login
        else:
            error_message = 'Invalid username or password'
            return render(request, 'dashboard/index.html', {'error_message': error_message})
    else:
        return render(request, 'dashboard/index.html')

def log(request):
    return redirect('dashboard')

@login_required(login_url='log')
def home(request):
    return render(request, 'dashboard/main/dashboard.html')
@login_required(login_url='log')
def Project(request):
    return render(request, 'dashboard/projectstatus.html')
@login_required(login_url='log')
def Services(request):
    product=Product.objects.all()
    context ={
        'product':product
    }
    return render(request, 'dashboard/services.html',context)
@login_required(login_url='log')
def Edit_Services(request,slug):
    product=get_object_or_404(Product, slug=slug)
    context ={
        'product':product
    }
    return render(request, 'dashboard/edit_services.html',context)
@login_required(login_url='log')
def Add_Services(request):
    return render(request, 'dashboard/add_services.html')
def Collection(request):
    return render(request, 'dashboard/collection.html')
def Add_Collection(request):
    return render(request, 'dashboard/add_collection.html')
def Calender(request):
    return render(request, 'dashboard/calender.html')
def Invoice(request):
    return render(request, 'dashboard/invoice.html')
def Feedback(request):
    return render(request, 'dashboard/feedback.html')