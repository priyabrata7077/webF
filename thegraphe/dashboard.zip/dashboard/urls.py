from .import views 
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('logout', views.logout_view, name='logout'),
    path('accounts/login/', views.log, name='log'),
    path('home', views.home, name='panel'),
    path('project_status', views.Project, name='Project'),
    path('services', views.Services, name='Services'),
    path('edit_services/<slug:slug>/', views.Edit_Services, name='edit_services'),
    path('add_services', views.Add_Services, name='add_services'),
    path('collection', views.Collection, name='Collection'),
    path('add_collection', views.Add_Collection, name='add_collection'),
    path('calender', views.Calender, name='calender'),
    path('invoice', views.Invoice, name='invoice'),
    path('feedback', views.Feedback, name='Feedback'),
]
